/**
*	NimSearch.java*
*	game search for Nim problems (Grundy's game)
*   subclass of GameSearch
*/


import java.util.*;

public class NimSearch extends GameSearch {

  //constructor

  /**
   * create a new search
   */

    public  NimSearch () {}


}










